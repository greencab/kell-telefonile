function toCelsius(f) {
    return (5/9) * (f-32);
}
